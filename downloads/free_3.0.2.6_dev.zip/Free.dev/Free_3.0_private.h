/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef FREE_3_0_PRIVATE_H
#define FREE_3_0_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"3.0.2.2"
#define VER_MAJOR	3
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	2
#define COMPANY_NAME	"Mantis"
#define FILE_VERSION	"3.0.2.2"
#define FILE_DESCRIPTION	"Free"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Copyright 2018"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Free 3.0(Upgrading)"
#define PRODUCT_VERSION	"3.0.2.2"

#endif /*FREE_3_0_PRIVATE_H*/
