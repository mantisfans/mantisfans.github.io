#pragma once

#include "pch.h"
/*
	Free 3.0�����еص�
*/

int Supermarket();

int WeaponShop();

int Bedroom();

int Kitchen();

int Home();

int Library();

int DiningHall();

int SchoolHistory();

int ObjectHouse();

int NeighborBedroom();

int Neighbor();

int SchoolHide();

int School3F();

int School2F();

int School1F();

int School();

int MER();

int Internal();

int OutWound();

int Hospital();

int Typist();

int Writing();

int ZooWest();

int ZooNorthWest();

int ZooMiddle();

int ZooNorth();

int ZooNorthEast();

int ZooEast();

int ZooOffice();

int Bank();

int Playground();

int City();

int Gate();
