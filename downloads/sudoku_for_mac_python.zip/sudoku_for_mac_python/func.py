from pch import *
import random
import copy
import time


class Solve(object):
    def __init__(self):
        # time_init = time.time()
        # print('---Solve_begin')

        self.ori_sd = copy.deepcopy(sd_0)

        self.N = 730
        self.M = 324 + 1

        self.V = self.N * self.M

        self.ele = [[0 for _ in range(self.M)] for _ in range(self.N)]

        self.bel = [[0 for _ in range(m)] for _ in range(n)]
        self.deci = [[0, 0, 0] for _ in range(self.N)]
        self.ele_cnt = 0

        self.sta = [0 for _ in range(self.N)]

        self.used = [0 for _ in range(self.M + 1)]

        self.found = 0

        self.pre = [0 for _ in range(self.V)]
        self.nxt = [0 for _ in range(self.V)]
        self.down = [0 for _ in range(self.V)]
        self.up = [0 for _ in range(self.V)]
        self.num_col = [0 for _ in range(self.M)]
        self.head_row = [-1 for _ in range(self.N)]
        self.row = [0 for _ in range(self.V)]
        self.col = [0 for _ in range(self.V)]
        self.node_id = 0

        self.n = 729
        self.m = 324

        self.calc_bel()

        # print('init_time:', time.time() - time_init)

    def init(self):
        for i in range(self.node_id + 1):
            self.pre[i] = 0
            self.nxt[i] = 0
            self.down[i] = 0
            self.up[i] = 0
            self.row[i] = 0
            self.col[i] = 0

        for i in range(self.ele_cnt + 1):
            for j in range(self.M):
                self.ele[i][j] = 0

        for i in range(self.M):
            self.num_col[i] = 0
        for i in range(self.N):
            self.head_row[i] = -1

        self.ele_cnt = 0
        self.node_id = 0
        self.found = 0

    def get_board(self, sd):
        self.init()
        self.ori_sd = copy.deepcopy(sd)

    def link(self, r, c):
        self.node_id += 1

        self.num_col[c] += 1
        self.row[self.node_id] = r
        self.col[self.node_id] = c

        self.up[self.node_id] = c
        self.down[self.node_id] = self.down[c]
        self.up[self.down[c]] = self.node_id
        self.down[c] = self.node_id

        if self.head_row[r] == -1:
            self.head_row[r] = self.pre[self.node_id] = self.nxt[self.node_id] = self.node_id
        else:
            self.nxt[self.node_id] = self.head_row[r]
            self.pre[self.node_id] = self.pre[self.head_row[r]]
            self.nxt[self.pre[self.head_row[r]]] = self.node_id
            self.pre[self.head_row[r]] = self.node_id

    def remove(self, x):
        self.nxt[self.pre[x]] = self.nxt[x]
        self.pre[self.nxt[x]] = self.pre[x]
        i = self.down[x]
        while i != x:

            j = self.nxt[i]
            while j != i:
                self.up[self.down[j]] = self.up[j]
                self.down[self.up[j]] = self.down[j]
                self.num_col[self.col[j]] -= 1

                j = self.nxt[j]

            i = self.down[i]

    def resume(self, x):
        i = self.down[x]
        while i != x:

            j = self.nxt[i]
            while j != i:
                self.up[self.down[j]] = j
                self.down[self.up[j]] = j
                self.num_col[self.col[j]] += 1

                j = self.nxt[j]

            i = self.down[i]

        self.nxt[self.pre[x]] = x
        self.pre[self.nxt[x]] = x

    def dance(self, dep):
        if self.nxt[0] == 0:
            # print(dep)
            for i in range(dep):
                x = self.sta[i]
                # # f = 0
                # if self.ele[x][1]:
                #     print('ohh! find me ', x)
                #     print('^^', x, end=' ')
                #     print(self.deci[x][0], self.deci[x][1], self.deci[x][2], end=' ')
                #     print('')
                # print('')
                if self.ori_sd[self.deci[x][0] - 1][self.deci[x][1] - 1] == 0:
                    self.ori_sd[self.deci[x][0] - 1][self.deci[x][1] - 1] = self.deci[x][2]

            self.found += 1
            if self.found >= 2:
                return True
            return False

        x = self.nxt[0]
        i = self.nxt[0]
        # print('#')
        while i != 0:
            if self.num_col[i] < self.num_col[x]:
                x = i

            i = self.nxt[i]
            # print(self.nxt[i])

        # print('remove', x)
        # print('#')
        # print(x)
        # print(self.row[x], self.col[x])
        # print(self.num_col[i])

        self.remove(x)

        i = self.down[x]
        while i != x:
            self.sta[dep] = self.row[i]

            j = self.nxt[i]
            while j != i:
                self.remove(self.col[j])
                j = self.nxt[j]

            if self.dance(dep + 1):
                return True

            j = self.nxt[i]
            while j != i:
                self.resume(self.col[j])
                j = self.nxt[j]

            i = self.down[i]

        # print('really been here')
        self.resume(x)
        return False

    def calc_bel(self):
        k = 0
        for i in range(3):
            for j in range(3):
                for x in range(3):
                    for y in range(3):
                        self.bel[i * 3 + x][j * 3 + y] = k
                k += 1

        # for i in range(9):
        #     for j in range(9):
        #         print(self.bel[i][j], end=' ')
        #     print('')

    def add_ele(self, x, y, u):
        self.ele_cnt += 1
        # print(x, y, u)
        # print(self.ele_cnt, 1 + x * 9 + u)
        self.ele[self.ele_cnt][1 + x * 9 + u] = 1
        self.ele[self.ele_cnt][82 + y * 9 + u] = 1
        self.ele[self.ele_cnt][163 + self.bel[x][y] * 9 + u] = 1
        self.ele[self.ele_cnt][244 + x * 9 + y] = 1
        self.deci[self.ele_cnt][0] = x + 1
        self.deci[self.ele_cnt][1] = y + 1
        self.deci[self.ele_cnt][2] = u + 1

    def get_ele(self, x, y):
        if self.ori_sd[x][y] != 0:
            self.add_ele(x, y, self.ori_sd[x][y] - 1)
            return

        for u in range(9):
            self.add_ele(x, y, u)

    def get_all_ele(self):
        for i in range(9):
            for j in range(9):
                self.get_ele(i, j)

    #
    # f = open('1.txt', 'w')
    #
    # print(self.ele_cnt, self.m, file=f)
    # for i in range(self.ele_cnt):
    #     for j in range(self.m):
    #         print(self.ele[i + 1][j + 1], end=' ', file=f)
    #     print('', file=f)

    #
    # for i in range(20):
    #     print('#', i)
    #     for j in range(243):
    #         if self.ele[i][j]:
    #             print(j, end=' ')
    #     print(self.deci[i])
    #     print('\self.N')

    # print('%', self.ele_cnt)
    # 1
    #
    # self.ele_cnt = 5
    # self.m = 5
    #
    # self.self.ele[1] = [0, 1, 1, 0, 0, 0]
    # self.self.ele[2] = [0, 1, 0, 0, 0, 0]
    # self.self.ele[3] = [0, 0, 0, 0, 1, 0]
    # self.self.ele[4] = [0, 0, 0, 1, 0, 0]
    # self.self.ele[5] = [0, 0, 0, 0, 0, 1]

    def link_init(self):

        # print(self.ele_cnt)

        for i in range(self.m + 1):
            self.pre[i] = i - 1
            self.nxt[i] = i + 1
            self.up[i] = self.down[i] = i

        self.pre[0] = self.m
        self.nxt[self.m] = 0
        self.node_id = self.m

    def links(self):
        for i in range(self.ele_cnt):
            for j in range(self.m):
                if self.ele[i + 1][j + 1]:
                    self.link(i + 1, j + 1)

        # for i in range(self.ele_cnt):
        #     print(i, ':')
        #     for j in range(self.m):
        #         if self.ele[i][j]:
        #             print(j, end=' ')
        #     print('')

        self.dance(0)
        #
        # if not self.dance(0):
        #     print('No solution!')
        #
        #
        # for i in range(9):
        #     for j in range(9):
        #         print(self.ori_sd[i][j], end=' ')
        #     print('')
        #
        # print("you've self.found", self.found, "solution(s)")
        # print('and spend calc time:', self.time_cnt)

    def faire(self):
        # time_before = time.time()
        self.get_all_ele()
        self.link_init()
        self.links()
        # time_apres = time.time()
        # print('faire time:', time_apres - time_before)
        # print('faire ele_cnt:', self.ele_cnt)

        # after links you will get a result found
        # 0 means no solution
        # 1 means exactly

        # now the result be in found

        # step = 0


class Make(object):

    def __init__(self, level):
        self.to_solve = Solve()

        self.level = level
        self.ori_sd = copy.deepcopy(sd_0)

        self.dfs_time = ...

        self.cur_sd = copy.deepcopy(self.ori_sd)

        self.make()

    def clean(self):
        for i in range(9):
            for j in range(9):
                self.ori_sd[i][j] = 0

    def dfs(self, dep, tar):
        print(dep)
        if time.time() - self.dfs_time > 5.0:
            return -1
        if dep == tar:
            # print('the cur_sd be like:')
            self.ori_sd = copy.deepcopy(self.cur_sd)
            # for i in range(9):
            #    print(self.cur_sd[i])
            return 1

        used = []
        cnt = 0
        for i in range(9):
            for j in range(9):
                if self.cur_sd[i][j] != 0:
                    used.append([i, j])
                    cnt += 1

        que = [_ for _ in range(cnt)]
        random.shuffle(que)

        for i in range(cnt):
            x = used[que[i]][0]
            y = used[que[i]][1]
            # print(x, y)
            self.cur_sd[x][y] = 0
            # print('#')
            # for j in range(9):
            #     print(self.cur_sd[j])
            # self.to_solve = Solve()
            self.to_solve.get_board(self.cur_sd)
            self.to_solve.faire()
            if self.to_solve.found == 1:
                res = self.dfs(dep + 1, tar)
                if res == 1:
                    return 1
                elif res == -1:
                    return -1
            self.cur_sd[x][y] = self.ori_sd[x][y]

        return 0

    def make(self):
        begin_time = time.time()
        while True:
            while True:
                t = 11
                self.clean()
                que = [j + 1 for j in range(9) for _ in range(9)]
                pos_que = [[i, j] for j in range(9) for i in range(9)]
                random.shuffle(que)
                random.shuffle(pos_que)
                while t:
                    x = pos_que[t][0]
                    y = pos_que[t][1]
                    u = que[t]
                    self.ori_sd[x][y] = u
                    t -= 1

                # print('the 11 board be like:')
                # for i in range(9):
                #     print(self.ori_sd[i])

                # self.to_solve = Solve()
                self.to_solve.get_board(self.ori_sd)
                self.to_solve.faire()

                if self.to_solve.found >= 1:
                    self.ori_sd = copy.deepcopy(self.to_solve.ori_sd)
                    break

            min_step = 10
            if self.level == 1:
                min_step = 81 - 80
            elif self.level == 2:
                min_step = 81 - 45
            elif self.level == 3:
                min_step = 81 - 25

            # time_before = time.time()
            # print('st dfs')

            self.dfs_time = time.time()

            self.cur_sd = copy.deepcopy(self.ori_sd)
            if self.dfs(0, min_step) == 1:
                break
            print('failed', time.time() - self.dfs_time)

        print('the final board is:')
        for i in range(9):
            ...
            print(self.ori_sd[i])

        end_time = time.time()
        print('level:', self.level)
        print('time spent:', end_time - begin_time, 'seconds')
