__author__ = 'Fjj, Wmy, Qac, Cyy, Zwy'
__version__ = '0.9.3.0'

import pygame.display

from func import *
from button import *
import copy
import math
import os
import sys


# make = Make(1)
# make.make()
# to_solve.get_board(make.ori_sd)
# to_solve.faire()
# print(to_solve.found)s
#
# pygame.init()
# screen = pygame.display.set_mode((480, 640))
# bg = pygame.image.load(r'pic/play.png')
# screen.blit(bg, (0, 0))
# pygame.display.update()

# global: screen


def playing():

    # including a buttons, sd..

    # text_surface = my_font.render('Preparing a perfect sudoku for you.', True, (255, 255, 255))
    # screen.blit(text_surface, (0, 0))
    # pygame.display.flip()

    screen.fill((255, 255, 255))
    clock = pygame.time.Clock()

    # menu:
    # part 1: try solving
    # part 2: judge if user wins

    # part 1: try solving

    # constant

    pos_exit_button = (43, 14)
    pos_finish_button = (149, 463)
    pos_clock = (280, 565)
    pos_give_up_button = (259, 473)

    def draw_rect(i, j, color, width=3):
        x = round(left_board + j * grid)
        y = round(up_board + i * grid)
        up_left = (x, y)
        up_right = (x + grid, y)
        down_left = (x, y + grid)
        down_right = (x + grid, y + grid)
        pygame.draw.lines(screen, color, True, (up_left, up_right, down_right, down_left), width)

    def draw_number(i, j, num, color):
        x = left_board + j * grid + (grid - font_size / 2) / 2
        y = up_board + i * grid + (grid - font_size) / 2
        if my_font_name == "Comic-Sans-MS":
            y -= 4

        text_surface = my_font.render('%d' % num, True, color)
        screen.blit(text_surface, (x, y))

    # def draw_bel(center, rect, bel):
    #     x = center[0] - rect[0] // 2
    #     y = center[1] - rect[1] // 2
    #     for i in range(rect[0]):
    #         for j in range(rect[1]):
    #             grid_bel[x + i][y + j] = bel

    def failed():
        pos_back_button = (180, 488)

        screen.fill((255, 255, 255))

        bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/failed.png"))

        mainloop = True
        while mainloop:
            clock.tick(FPS)
            screen.fill((255, 255, 255))
            screen.blit(bg, (0, 0))

            back_button = Button(screen, 'Go back.', COLOR_SYS_TEXT, sys_regular_font,
                                 pos_back_button[0], pos_back_button[1])
            if back_button.check_click(pygame.mouse.get_pos()):
                back_button = Button(screen, 'Go back.', COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                     pos_back_button[0], pos_back_button[1])
            back_button.display()

            pygame.display.update()

            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if back_button.check_click(pygame.mouse.get_pos()):
                        # mainloop = 0
                        return

    def get_level():
        pos_level1_button = (54, 200)
        pos_level2_button = (54, 300)
        pos_level3_button = (54, 400)

        screen.fill((255, 255, 255))

        # bg = pygame.image.load("pic/failed.png")

        mainloop = True
        while mainloop:
            clock.tick(FPS)
            screen.fill((255, 255, 255))
            screen.blit(sys_wide_font.render('Choose your level!', True, COLOR_SYS_TEXT), (100, 80))

            level1_button = Button(screen, '          Trial Mode', COLOR_SYS_TEXT, sys_regular_font,
                                   pos_level1_button[0], pos_level1_button[1])
            if level1_button.check_click(pygame.mouse.get_pos()):
                level1_button = Button(screen, 'Only 1 blank grid for trial',
                                       COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                       pos_level1_button[0], pos_level1_button[1])
            level1_button.display()

            level2_button = Button(screen, '            Medium', COLOR_SYS_TEXT, sys_regular_font,
                                   pos_level2_button[0], pos_level2_button[1])
            if level2_button.check_click(pygame.mouse.get_pos()):
                level2_button = Button(screen, '       45 numbers left', COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                       pos_level2_button[0], pos_level2_button[1])
            level2_button.display()

            level3_button = Button(screen, '               Hard', COLOR_SYS_TEXT, sys_regular_font,
                                   pos_level2_button[0], pos_level3_button[1])
            if level3_button.check_click(pygame.mouse.get_pos()):
                level3_button = Button(screen, '   Only 25 numbers left!',
                                       COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                       pos_level3_button[0], pos_level3_button[1])
            level3_button.display()

            pygame.display.update()

            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    res = 0
                    if level1_button.check_click(pygame.mouse.get_pos()):
                        res = 1
                    if level2_button.check_click(pygame.mouse.get_pos()):
                        res = 2
                    if level3_button.check_click(pygame.mouse.get_pos()):
                        res = 3
                    if res:
                        bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/making.png"))
                        screen.blit(bg, (0, 0))
                        pygame.display.update()
                        return res

    def give_up(ori_sd, my_sd, ans_sd):
        bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/give_up.png"))

        # button init

        mainloop = True
        while mainloop:

            # ---------- begin render
            # render()
            screen.fill((255, 255, 255))
            screen.blit(bg, (0, 0))

            exit_button = Button(screen, 'Exit', COLOR_SYS_HIGHLIGHTED_TEXT, sys_wide_font,
                                 pos_exit_button[0], pos_exit_button[1])
            if exit_button.check_click(pygame.mouse.get_pos()):
                exit_button = Button(screen, 'Exit', COLOR_SYS_HIGHLIGHTED_TEXT, sys_wide_font,
                                     pos_exit_button[0], pos_exit_button[1])
            exit_button.display()

            # if any_ill:
            #    screen.blit(sys_small_font.render('Press SPACE to clear a grid.', True, COLOR_SYS_TEXT), (145, 55))

            for i in range(10):
                x = left_board
                y = up_board + i * grid
                pygame.draw.line(screen, COLOR_LINES, (x, y), (x + m * grid, y), strong_line if i % 3 == 0 else
                                 thin_line)

            for j in range(10):
                x = left_board + j * grid
                y = up_board
                pygame.draw.line(screen, COLOR_LINES, (x, y), (x, y + n * grid),
                                 strong_line if j % 3 == 0 else thin_line)

            # if label_exit == 1:
            #     img = pygame.image.load("pic/label_exit.png")
            #     # screen.blit(pos_exit_button[0] - )
            # elif label_exit == 2:
            #     img = pygame.image.load("pic/label_exit_big.png")
            #     screen.blit()

            # text_surface = my_font.render('Some Text', False, (0, 0, 0))
            # screen.blit(text_surface, (0, 0))
            # render end

            for i in range(9):
                for j in range(9):
                    if ori_sd[i][j]:
                        draw_number(i, j, ans_sd[i][j], COLOR_ORI_NUMBERS)
                    else:
                        if my_sd[i][j] == ans_sd[i][j]:
                            draw_number(i, j, ans_sd[i][j], COLOR_CORRECT_NUMBERS)
                        else:
                            draw_number(i, j, ans_sd[i][j], COLOR_ORI_WRONG_NUMBERS)

            # ---------- end render
            pygame.display.update()

            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if exit_button.check_click(pygame.mouse.get_pos()):
                        return

        return

    def playing_main():
        ci, cj = 0, 0
        head = 0
        que_size = int(FPS * move_time)
        que_fac = [.0 for _ in range(que_size)]
        last_list = [(ci, cj) for _ in range(que_size)]
        grid_bel = [[(-1, -1) for _ in range(screen_height + 1)] for _ in range(screen_width + 1)]

        que_sum = 0
        for i in range(que_size):
            # que_fac[i] = math.factorial(que_size - 1) // (math.factorial(i) * math.factorial(que_size - 1 - i))
            que_fac[i] = math.sin(i / que_size * math.pi / 2 + math.pi / 2)
            que_sum += que_fac[i]
        for i in range(que_size):
            que_fac[i] /= que_sum

        for i in range(9):
            for j in range(9):
                x = left_board + j * grid
                y = up_board + i * grid
                for u in range(grid):
                    for v in range(grid):
                        grid_bel[x + u][y + v] = (i, j)

        bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/playing.png"))

        # button init

        # draw_bel(grid_bel, pos_exit_button, label_exit_size, LABEL_EXIT)

        make_sd_pro = Make(get_level())
        ori_sd = copy.deepcopy(make_sd_pro.ori_sd)
        my_sd = copy.deepcopy(make_sd_pro.ori_sd)

        mainloop = True
        begin_time = pygame.time.get_ticks()
        while mainloop:
            clock.tick(FPS)
            # fps = clock.get_fps()
            # print('fps:', fps)

            sd_full = 1
            for i in range(9):
                for j in range(9):
                    if my_sd[i][j] == 0:
                        sd_full = 0

            head = (head + 1) % que_size
            last_list[head] = (ci, cj)
            pi, pj = 0, 0
            for i in range(que_size):
                que_id = (head - i + que_size) % que_size
                pi += last_list[i][0] * que_fac[que_id]
                pj += last_list[i][1] * que_fac[que_id]

            # print(pi, pj)

            cur_time = pygame.time.get_ticks()
            tot_time = (cur_time - begin_time) / 1000
            # ---------- begin render
            # render()
            screen.fill((255, 255, 255))
            screen.blit(bg, (0, 0))

            exit_button = Button(screen, 'Exit', COLOR_SYS_TEXT, sys_wide_font,
                                 pos_exit_button[0], pos_exit_button[1])
            if exit_button.check_click(pygame.mouse.get_pos()):
                exit_button = Button(screen, 'Exit', COLOR_SYS_HIGHLIGHTED_TEXT, sys_wide_font,
                                     pos_exit_button[0], pos_exit_button[1])
            exit_button.display()

            finish_button = Button(screen, 'Finish', COLOR_SYS_TEXT, sys_regular_font,
                                   pos_finish_button[0], pos_finish_button[1])
            if not sd_full:
                # hide
                finish_button = Button(screen, 'Finish', COLOR_SYS_GRAY_TEXT, sys_regular_font,
                                       pos_finish_button[0], pos_finish_button[1])
            elif finish_button.check_click(pygame.mouse.get_pos()):
                finish_button = Button(screen, 'Finish', COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                       pos_finish_button[0], pos_finish_button[1])
            finish_button.display()

            give_up_button = Button(screen, 'Give up', COLOR_SYS_TEXT, sys_small_font,
                                    pos_give_up_button[0], pos_give_up_button[1])
            if give_up_button.check_click(pygame.mouse.get_pos()):
                give_up_button = Button(screen, '& show answer', COLOR_SYS_HIGHLIGHTED_TEXT, sys_small_font,
                                        pos_give_up_button[0], pos_give_up_button[1])
            give_up_button.display()
            # for i in range(9):
            #     for j in range(9):
            #         # rc = ()
            #         # rp = (left_board + j * grid, up_board + i * grid)
            #         # rs = (grid, grid)
            #         # pygame.draw.rect(screen, rp, rs)
            #         draw_rect(screen, i, j, (80, 80, 80))

            # check if there exists some grid wrong!
            any_ill = 0
            ill_sd = copy.deepcopy(sd_0)
            for i in range(9):
                # pygame.draw.rect(screen, BLACK, (50, 50, 150, 50), 0)
                used = [0 for _ in range(9)]
                x = left_board
                y = up_board + i * grid
                for j in range(9):
                    if my_sd[i][j] != 0:
                        used[my_sd[i][j] - 1] += 1
                ill = 0
                for num in range(9):
                    if used[num] >= 2:
                        ill = 1
                        if ci == i:
                            for j in range(9):
                                if my_sd[i][j] - 1 == num:
                                    ill_sd[i][j] = 1
                if ill:
                    if ci == i:
                        pygame.draw.rect(screen, COLOR_WARNING, (x, y, 9 * grid, grid))
                    any_ill = 1

            for j in range(9):
                # pygame.draw.rect(screen, BLACK, (50, 50, 150, 50), 0)
                used = [0 for _ in range(9)]
                x = left_board + j * grid
                y = up_board
                for i in range(9):
                    if my_sd[i][j] != 0:
                        used[my_sd[i][j] - 1] += 1
                ill = 0
                for num in range(9):
                    if used[num] >= 2:
                        ill = 1
                        if cj == j:
                            for i in range(9):
                                if my_sd[i][j] - 1 == num:
                                    ill_sd[i][j] = 1

                if ill:
                    if cj == j:
                        pygame.draw.rect(screen, COLOR_WARNING, (x, y, grid, grid * 9))
                    any_ill = 1

            for i in range(3):
                for j in range(3):
                    used = [0 for _ in range(9)]
                    x = left_board + j * 3 * grid
                    y = up_board + i * 3 * grid
                    for u in range(3):
                        for v in range(3):
                            if my_sd[i * 3 + u][j * 3 + v] != 0:
                                used[my_sd[i * 3 + u][j * 3 + v] - 1] += 1
                    ill = 0
                    for num in range(9):
                        if used[num] >= 2:
                            ill = 1
                            if ci // 3 == i and cj // 3 == j:
                                for u in range(3):
                                    for v in range(3):
                                        if my_sd[i * 3 + u][j * 3 + v] - 1 == num:
                                            ill_sd[i * 3 + u][j * 3 + v] = 1
                    if ill:
                        if ci // 3 == i and cj // 3 == j:
                            pygame.draw.rect(screen, COLOR_WARNING, (x, y, grid * 3, grid * 3))
                        any_ill = 1

            if any_ill:
                ...
            # do nothing
            #    screen.blit(sys_small_font.render('Press SPACE to clear a grid.', True, COLOR_SYS_TEXT), (145, 55))

            for i in range(10):
                x = left_board
                y = up_board + i * grid
                pygame.draw.line(screen, COLOR_LINES, (x, y), (x + m * grid, y), strong_line if i % 3 == 0 else
                                 thin_line)

            for j in range(10):
                x = left_board + j * grid
                y = up_board
                pygame.draw.line(screen, COLOR_LINES, (x, y), (x, y + n * grid),
                                 strong_line if j % 3 == 0 else thin_line)

            draw_rect(pi, pj, COLOR_CHOSEN_GRID, strong_line)

            # if label_exit == 1:
            #     img = pygame.image.load("pic/label_exit.png")
            #     # screen.blit(pos_exit_button[0] - )
            # elif label_exit == 2:
            #     img = pygame.image.load("pic/label_exit_big.png")
            #     screen.blit()

            # text_surface = my_font.render('Some Text', False, (0, 0, 0))
            # screen.blit(text_surface, (0, 0))
            # render end

            for i in range(9):
                for j in range(9):
                    if my_sd[i][j] == 0:
                        continue
                    if ori_sd[i][j] == 0:
                        # this my user
                        if not ill_sd[i][j]:
                            draw_number(i, j, my_sd[i][j], COLOR_MY_NUMBERS)
                        else:
                            draw_number(i, j, my_sd[i][j], COLOR_WRONG_NUMBERS)
                    else:
                        if not ill_sd[i][j]:
                            draw_number(i, j, my_sd[i][j], COLOR_ORI_NUMBERS)
                        else:
                            draw_number(i, j, my_sd[i][j], COLOR_ORI_WRONG_NUMBERS)

            # for event in pygame.event.get():
                # if event.type == pygame.QUIT:
                #     pygame.sys.exit()
                #     sys.exit()

            clock_str = "%d : %02d : %02d" % (tot_time / 3600, tot_time % 3600 / 60, tot_time % 60)
            clock_surface = sys_clock_font.render(clock_str, True, COLOR_SYS_TEXT)
            screen.blit(clock_surface, pos_clock)
            # ---------- end render
            pygame.display.update()

            event_list = pygame.event.get()
            for event in event_list:

                if event.type == pygame.QUIT:
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    # print(event.key - pygame.K_KP0)
                    if event.key == pygame.K_UP:
                        ci = (ci + 8) % n
                    elif event.key == pygame.K_DOWN:
                        ci = (ci + 1) % n
                    elif event.key == pygame.K_RIGHT:
                        cj = (cj + 1) % m
                    elif event.key == pygame.K_LEFT:
                        cj = (cj + 8) % m
                    elif pygame.K_0 <= event.key <= pygame.K_9:
                        if ori_sd[ci][cj] != 0:
                            continue
                        my_sd[ci][cj] = event.key - pygame.K_0
                        ...
                    elif pygame.K_KP1 <= event.key <= pygame.K_KP0:
                        if ori_sd[ci][cj] != 0:
                            continue
                        if event.key == pygame.K_KP0:
                            my_sd[ci][cj] = 0
                        else:
                            my_sd[ci][cj] = event.key - pygame.K_KP1 + 1
                        ...
                    elif event.key == pygame.K_SPACE:
                        if ori_sd[ci][cj] != 0:
                            continue
                        my_sd[ci][cj] = 0

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if grid_bel[pos[0]][pos[1]] != (-1, -1):
                        ci, cj = grid_bel[pos[0]][pos[1]]
                    ...
                    if exit_button.check_click(pygame.mouse.get_pos()):
                        # mainloop = 0
                        return FACE_WELCOME

                    if sd_full and finish_button.check_click(pygame.mouse.get_pos()):

                        if sd_full == 1:
                            to_solve = Solve()
                            to_solve.get_board(my_sd)
                            to_solve.faire()
                            if to_solve.found == 1 and sd_full:
                                return FACE_SUCCEED
                            else:
                                failed()
                        else:
                            ...
                    if give_up_button.check_click(pygame.mouse.get_pos()):
                        to_solve = Solve()
                        to_solve.get_board(ori_sd)
                        to_solve.faire()
                        give_up(ori_sd, my_sd, to_solve.ori_sd)
                        return FACE_WELCOME
                        # do nothing
                    # for function playing_game
                elif event.type == pygame.MOUSEMOTION:
                    ...

        return FACE_EXIT

    return playing_main()


def welcome():
    pos_play_button = (127, 403)
    screen.fill((255, 255, 255))
    clock = pygame.time.Clock()

    bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/welcome.png"))

    mainloop = True
    while mainloop:
        clock.tick(FPS)
        screen.fill((255, 255, 255))
        screen.blit(bg, (0, 0))

        screen.blit(sys_small_font.render('Version: ' + __version__, True, COLOR_SYS_TEXT), (138, 295))
        screen.blit(sys_small_font.render('Author: ' + __author__, True, COLOR_SYS_TEXT), (138, 335))

        play_button = Button(screen, 'Play', COLOR_SYS_TEXT, sys_init_font,
                             pos_play_button[0], pos_play_button[1])
        if play_button.check_click(pygame.mouse.get_pos()):
            play_button = Button(screen, 'Play', COLOR_SYS_HIGHLIGHTED_TEXT, sys_init_font,
                                 pos_play_button[0], pos_play_button[1])
        play_button.display()

        pygame.display.update()

        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.check_click(pygame.mouse.get_pos()):
                    # mainloop = 0
                    return FACE_PLAYING

    return FACE_EXIT


def succeed():

    pos_exit_button = (43, 28)
    pos_try_button = (117, 508)

    screen.fill((255, 255, 255))
    clock = pygame.time.Clock()

    bg = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), "pic/succeed.png"))

    mainloop = True
    while mainloop:
        clock.tick(FPS)
        screen.fill((255, 255, 255))
        screen.blit(bg, (0, 0))

        exit_button = Button(screen, 'Exit', COLOR_SYS_TEXT, sys_wide_font,
                             pos_exit_button[0], pos_exit_button[1])
        if exit_button.check_click(pygame.mouse.get_pos()):
            exit_button = Button(screen, 'Exit', COLOR_SYS_HIGHLIGHTED_TEXT, sys_wide_font,
                                 pos_exit_button[0], pos_exit_button[1])
        exit_button.display()

        try_button = Button(screen, 'Try another one?', COLOR_SYS_TEXT, sys_regular_font,
                            pos_try_button[0], pos_try_button[1])
        if try_button.check_click(pygame.mouse.get_pos()):
            try_button = Button(screen, 'GOOD LUCK!!!!!', COLOR_SYS_HIGHLIGHTED_TEXT, sys_regular_font,
                                pos_try_button[0], pos_try_button[1])
        try_button.display()

        pygame.display.update()

        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if exit_button.check_click(pygame.mouse.get_pos()):
                    # mainloop = 0
                    return FACE_WELCOME
                if try_button.check_click(pygame.mouse.get_pos()):
                    # mainloop = 0
                    return FACE_PLAYING

    return FACE_EXIT


pygame.init()
pygame.display.set_caption("Sudoku")
icon = pygame.image.load(os.path.join(os.path.dirname(sys.argv[0]), 'pic/icon.png'))
pygame.display.set_icon(icon)
screen = pygame.display.set_mode((screen_width, screen_height))


def main():
    face = FACE_WELCOME
    while face:
        if face == FACE_WELCOME:
            face = welcome()
        elif face == FACE_PLAYING:
            face = playing()
        elif face == FACE_SUCCEED:
            face = succeed()
            ...
        elif face == FACE_FAILED:
            ...
        elif face == FACE_GIVE_UP:
            ...


if __name__ == "__main__":
    main()
else:
    ...
#    print("i was imported by", __name__)

# game = Game()
# game.show()

# for i in range(9):
#   for j in range(9):

input("please input any key to exit!")
