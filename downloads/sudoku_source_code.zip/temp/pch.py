__platform__ = "Mac OS"

import pygame
import sys
import os

n = 9
m = 9

default_level = 1

COLOR_LINES = (0, 0, 0)

COLOR_ORI_NUMBERS = (0, 0, 0)
COLOR_MY_NUMBERS = (168, 168, 168)
COLOR_CORRECT_NUMBERS = (168, 168, 168)
COLOR_WRONG_NUMBERS = (255, 127, 127)
COLOR_ORI_WRONG_NUMBERS = (200, 0, 0)

COLOR_SYS_TEXT = (0, 0, 0)
COLOR_SYS_HIGHLIGHTED_TEXT = (100, 100, 100)
COLOR_SYS_GRAY_TEXT = (200, 200, 200)
COLOR_WARNING = (255, 255, 224)
COLOR_CHOSEN_GRID = (255, 34, 34)

strong_line = 4
thin_line = 1

sd_0 = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],

            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],

            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0]
        ]

grid = 38
left_board = 66
up_board = 70
frame_time = 20
FPS = 120
move_time = 0.10

screen_width = 480
screen_height = 640

font_size = 26
sys_font_size = 38
sys_init_font_size = 52
clock_font_size = 18
sys_small_size = 22
my_font_name = "Comic-Sans-MS"
# out_font_name = "Marker felt"
pygame.font.init()
my_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]), "font/" + my_font_name + ".ttf"), font_size)
# out_font = pygame.font.SysFont(out_font_name, sys_font_size)
# os.path.join(os.path.dirname(sys.argv[0]), "font/" + my_font_name + ".ttf")
# o
sys_regular_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]),
                                                 'font/Marker Felt.ttf'), sys_font_size)
sys_wide_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]),
                                              'font/MarkerFeltWide Regular.ttf'), sys_font_size)
sys_init_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]),
                                              'font/MarkerFeltWide Regular.ttf'), sys_init_font_size)
sys_clock_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]),
                                               'font/Marker Felt.ttf'), clock_font_size)
sys_small_font = pygame.font.Font(os.path.join(os.path.dirname(sys.argv[0]),
                                               'font/Marker Felt.ttf'), sys_small_size)

FACE_WELCOME = 1
FACE_PLAYING = 2
FACE_SUCCEED = 3
FACE_FAILED = 4
FACE_GIVE_UP = 5
FACE_EXIT = 0

LABEL_EXIT = (9, 0)
LABEL_FINISHED = (9, 1)
LABEL_GIVE_UP = (9, 2)

CLICK_EFFECT_TIME = 100

# you have to call this at the start,
# if you want to use this module.
